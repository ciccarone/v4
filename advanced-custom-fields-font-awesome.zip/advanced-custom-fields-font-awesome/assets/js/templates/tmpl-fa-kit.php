<script type="text/html" id="tmpl-fa-kit">
	<tr>
		<td><input type="radio" name="acffa_settings[acffa_kit]" {{data.checked}} value="{{data.token}}"></td>
		<td>{{data.name}}</td>
		<td>{{data.token}}</td>
		<td>{{data.status}}</td>
		<td>{{data.licenseSelected}}</td>
		<td>{{data.technologySelected}}</td>
		<td>{{data.customIconCount}}</td>
		<td>{{data.version}}</td>
	</tr>
</script>